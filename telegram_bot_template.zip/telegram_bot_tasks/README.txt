🔧 Как использовать этот проект:

1. Установи библиотеку:
   pip install pyTelegramBotAPI

2. Вставь свой токен в файл config.py вместо "YOUR_TOKEN_HERE".

3. Запусти бота:
   python bot.py

Бот включает мини-задачи:
- /start — ввод имени и возраста
- /buttons — кнопка с callback-обработкой